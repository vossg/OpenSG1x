using _STLP_NEW_IO_NAMESPACE::strstreambuf;
using _STLP_NEW_IO_NAMESPACE::istrstream;
using _STLP_NEW_IO_NAMESPACE::ostrstream;
using _STLP_NEW_IO_NAMESPACE::strstream;
