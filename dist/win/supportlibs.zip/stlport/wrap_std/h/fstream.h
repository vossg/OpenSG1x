# include _STLP_NATIVE_OLD_STREAMS_HEADER(fstream.h)
# if defined  (_STLP_USE_NAMESPACES) && ! defined (_STLP_BROKEN_USING_DIRECTIVE)
_STLP_BEGIN_NAMESPACE
#  include <using/h/fstream.h>
_STLP_END_NAMESPACE
# endif /* _STLP_OWN_NAMESPACE */

