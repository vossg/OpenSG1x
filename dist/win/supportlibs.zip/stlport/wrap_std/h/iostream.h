// # ifndef  _STLP_NO_WCHAR_T
// #   include <wchar.h>
// # endif

# include _STLP_NATIVE_OLD_STREAMS_HEADER(iostream.h)

# if defined (_STLP_USE_OWN_NAMESPACE)
_STLP_BEGIN_NAMESPACE
# include <using/h/iostream.h>
_STLP_END_NAMESPACE
# endif /* _STLP_USE_OWN_NAMESPACE */
