
OpenSG Support Libs for Windows
===============================

This directory contains a bunch of support libraries that are needed to
compile OpenSG and programs based on OpenSG, and which are not standard on 
Windows.

The libraries are available on the Internt under different conditions. See
the README files in sources/ for details. For most libraries the sources are 
in that directory, in any case there are links to web pages where they can be
obtained.

When using these for Visual Studio, make sure to include the "include" dir in
the include pathlist (Tools->Options->Projects->VC++ Directories->Include Files
for VS.NET, similar for VS6) and "lib" in the lib pathes (Tools->Options->
Projects->VC++ Directories->Library Files). 

When using them for a cygwin build just extract them to the OpenSG main directory 
and inclued them in the configure command.



