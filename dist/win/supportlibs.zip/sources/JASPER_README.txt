JasPer Readme
*************

This is the source code distribution for JasPer.  JasPer is a collection
of software (i.e., a library and application programs) for the coding
and manipulation of images.  This software can handle image data in a
variety of formats.  One such format supported by JasPer is the JPEG-2000
format defined in ISO/IEC 15444-1.

The complete licensing terms for the JasPer software can be found in
the file named "LICENSE" in the top level directory of this software
distribution.  Any use of this software contrary to the terms of the
license is strictly prohibited.  The changes made to the software
since the last release are described in the file "NEWS".  Detailed
documentation on the JasPer software can be found in the JasPer Software
Reference Manual.  This manual is located in the "doc" directory, and
includes useful information such as: 1) how to build, install, and use
the software, 2) how to submit report bugs, and 3) where to find
additional information about the software.

Enjoy! :)

