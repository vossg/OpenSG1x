**********************************************************************
* 	README file for STLport 4.5                                  *
*                                                                    *
**********************************************************************

This directory contains STLport-4.5 release.

What's inside :

README      - this file
INSTALL     - installation instructions

stlport     - main STLport include directory
src         - source and makefiles for iostreams implementation
lib         - installation directory for STLport library (if you use STLport iostreams only)
test/regression   - regression test, using wrapper iostreams
test/eh     - exception handling test using STLport iostreams
etc         - miscellanous files (ChangeLog, TODO, scripts, etc.) 

GETTING STLPORT

To download the latest version of STLport, please be sure to visit
http://www.stlport.com/download.html

LEGALESE

This software is being distributed under the following terms :

 *
 *
 * Copyright (c) 1994
 * Hewlett-Packard Company
 *
 * Copyright (c) 1996-1999
 * Silicon Graphics Computer Systems, Inc.
 *
 * Copyright (c) 1997
 * Moscow Center for SPARC Technology
 *
 * Copyright (c) 1999, 2000, 2001
 * Boris Fomitchev
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 *

**********************************************************************

